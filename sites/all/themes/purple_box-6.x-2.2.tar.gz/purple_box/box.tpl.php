<?php
// $Id: box.tpl.php,v 1.1 2008/08/12 20:32:34 doncoryon Exp $
?>
  <div class="box">
    <?php if ($title) { ?><h2 class="title"><?php print $title; ?></h2><?php } ?>
    <div class="content"><?php print $content; ?></div>
 </div>

